import React, { Component } from 'react';
import { BrowserRouter, Route, Redirect, Switch } from 'react-router-dom';

import AuthPage from './pages/Auth';
import ProjectsPage from './pages/Projects';
import EditorPage from './pages/Editor';
import CreateAccountPage from './pages/CreateAccount';
import MainNavigation from './components/Navigation/MainNavigation';
import AuthContext from './context/auth-context';

import './App.css';

class App extends Component {
  state = {
    token: null,
    userId: null
  };

  componentDidMount() {
    this.verifyUser();
  }

  verifyUser = () => {
    this.setState({token: localStorage.getItem("TOKEN"), userId: localStorage.getItem("USER_ID")});
  }

  login = (token, userId, tokenExpiration) => {
    localStorage.setItem("TOKEN", token);
    localStorage.setItem("EXPIRES_IN", tokenExpiration);
    localStorage.setItem("USER_ID", userId);
    this.setState({ token: token, userId: userId });
  };

  logout = () => {
    this.setState({ token: null, userId: null });
    localStorage.removeItem("TOKEN");
    localStorage.removeItem("EXPIRES_IN");
    localStorage.removeItem("USER_ID");
  };

  render() {
    return (
      <BrowserRouter>
        <React.Fragment>
          <AuthContext.Provider
            value={{
              token: this.state.token,
              userId: this.state.userId,
              login: this.login,
              logout: this.logout
            }}>
            <div className="grid-container">
              <MainNavigation />
              <main>
                <Switch>
                  {this.state.token &&
                    <Redirect from="/" to="/projects" exact />
                  }
                  {this.state.token && (
                    <Redirect from="/auth" to="/projects" exact />
                  )}
                  {this.state.token && (
                    <Redirect from="/createAccount" to="/projects" exact />
                  )}


                  {!this.state.token && (
                    <Route path="/auth" component={AuthPage} />
                  )}
                  {!this.state.token && (
                    <Route path="/createAccount" component={CreateAccountPage} />
                  )}
                  {this.state.token && (
                    <Route path="/projects" component={ProjectsPage} />
                  )}
                  {this.state.token && (
                    <Route path="/editor" component={EditorPage} />
                  )}

                  {!this.state.token &&
                    <Redirect to="/auth" exact />
                  }
                </Switch>
              </main>
            </div>
          </AuthContext.Provider>
        </React.Fragment>
      </BrowserRouter>
    );
  }
}

export default App;
