import React, { Component } from 'react';

import Modal from '../components/Modal/Modal';
import Backdrop from '../components/Backdrop/Backdrop';
import AuthContext from '../context/auth-context';

import './Editor.css';
import { initDiagram, getModelJson, getImage_B64, onMoreInfo, makeBlob } from '../scripts/went';

export function updateState(moreInfo) {
    this.setState({ moreInfo });
}

class EditorPage extends Component {
    constructor(props) {
        super(props)
        this.state = {
            projectId: null,
            projectTitle: null,
            projectCanvasJSON: null,
            menuOptions: false,
            moreInfo: false
        }
        updateState = updateState.bind(this);
    }

    static contextType = AuthContext;

    componentDidMount() {
        this.fetchEvents();
    }

    fetchEvents() {
        this.state.projectId = this.props.location.state.projectId;
        this.state.projectTitle = this.props.location.state.title;
        this.state.projectCanvasJSON = this.props.location.state.canvasJSON;

        initDiagram(this.state.projectCanvasJSON);

    }

    optionsEventHandler = () => {
        this.setState({ menuOptions: true });
    };

    //MODALES EVENTOS

    modalCancelHandler = () => {
        this.setState({ menuOptions: false, moreInfo: false });
    };

    modalConfirmHandler = () => {
        this.setState({ menuOptions: false });
        const newCanvasJSON = getModelJson();
        const lastAccessDate = new Date().toISOString();
        const lastUpdateDate = new Date().toISOString();
        const image = getImage_B64();

        const requestBody = {
            query: `
                mutation {
                    saveProject(projectSave:{ projectId: "${this.state.projectId}", canvasJSON: ${JSON.stringify(newCanvasJSON)}, lastAccessDate: "${lastAccessDate}", lastUpdateDate: "${lastUpdateDate}", image: "${image}"}) {
                        _id
                        title
                    }
                }
            `
        };

        fetch('http://localhost:8000/graphql', {
            method: 'POST',
            body: JSON.stringify(requestBody),
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + this.context.token
            }
        }).then(res => {
            if (res.status !== 200 && res.status !== 201) {
                throw new Error('Failed!');
            }
            return res.json();
        }).then(resData => {
            alert("Project saved.");
        }).catch(err => {
            console.log(err);
        });
    };

    modalExitHandler = () => {
        //this.setState({ menuOptions: false });

    };

    modalDownloadHandler = () => {
        this.setState({ menuOptions: false });
        makeBlob();
    };

    concatListImgs = () => {
        let IImages = "";
        for (let i = 0; i < onMoreInfo.images.length; i++) {
            IImages = IImages.concat("<li><img width='170px' src='" + onMoreInfo.images[i].url + "' ></li>");
        }
        return IImages;
    }

    render() {
        return (
            <React.Fragment>
                {(this.state.menuOptions || this.state.moreInfo) && <Backdrop />}
                {this.state.menuOptions && (
                    <Modal
                        title="Options"
                        canCancel
                        canConfirm
                        canExit
                        canDownload
                        onCancel={this.modalCancelHandler}
                        onConfirm={this.modalConfirmHandler}
                        onExit={this.modalExitHandler}
                        onDownload={this.modalDownloadHandler}
                        confirmText="Save Project">

                    </Modal>
                )}
                {this.state.moreInfo && (
                    <Modal
                        title={onMoreInfo.title}
                        canCancel
                        onCancel={this.modalCancelHandler}>

                        {onMoreInfo.overview.join("") + onMoreInfo.characteristics.join("")}
                        <b>Images</b><br />
                        <div className="div-collImgs">
                            <ul>
                                {this.concatListImgs()}
                            </ul>
                        </div>
                    </Modal>
                )}
                <div className="editor-content">
                    <div id="divDiagram" className="div-drawPanel"></div>
                    <div id="divDiagramCode" className="div-drawPanel"></div>
                    <div className="div-toolPanel">
                        <div className="div-componentPanel">
                            <div id="divTitle" className="div-title">
                                Components
                            </div>
                            <div id="divSearchC" className="div-searchPanel">
                                <img width="27" height="27" alt="" />
                                <input id="txtSearchC" type="text" placeholder="Search" />
                            </div>
                            <div id="listComponents" className="div-list"></div>
                            <div id="listSentences" className="div-list"></div>
                        </div>
                        <div className="div-infoPanel">
                            <div className="div-title">
                                Overview
                            </div>
                            <div id="div-overview"></div>
                            <div id="div-overviewCode"></div>
                        </div>
                    </div>
                    <div className="div-footPanel">
                        <div className="div-messagePanel">

                        </div>
                        <div className="div-tabPanel">
                            <button onClick={this.optionsEventHandler}>Options</button>
                            <button id="btnSwitch">Code</button>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default EditorPage;