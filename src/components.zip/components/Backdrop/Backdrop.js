import React from 'react';

import './Backdrop.css';

const backdrop = props => <div className="backdrop"></div>;

export default backdrop;